/**
 * Custom events used by SkBee
 */
package com.shanebeestudios.skbee.api.event;
