/**
 * Utility and wrapper classes for {@link org.bukkit.structure.Structure Structures}
 */
package com.shanebeestudios.skbee.api.structure;
