/**
 * General utility classes
 */
package com.shanebeestudios.skbee.api.util;
