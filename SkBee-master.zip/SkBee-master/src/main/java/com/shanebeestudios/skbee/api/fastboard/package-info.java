/**
 * General classes for scoreboards
 */
package com.shanebeestudios.skbee.api.fastboard;
