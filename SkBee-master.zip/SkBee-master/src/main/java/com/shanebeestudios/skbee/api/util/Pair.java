package com.shanebeestudios.skbee.api.util;

public record Pair<A, B>(A first, B second) {
}
