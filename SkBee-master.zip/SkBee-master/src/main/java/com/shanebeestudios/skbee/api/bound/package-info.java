/**
 * General classes for {@link com.shanebeestudios.skbee.api.bound.Bound bounds}
 */
package com.shanebeestudios.skbee.api.bound;
