/**
 * General wrapper classes
 */
package com.shanebeestudios.skbee.api.wrapper;
